//
//  SpecialSubjectDetailViewController.h
//  EarBook
//
//  Created by lanou3g on 16/6/28.
//  Copyright © 2016年 赵符壹. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BookMP3;
@interface SpecialSubjectDetailViewController : UIViewController

@property (nonatomic, strong) BookMP3 *book;

@end
