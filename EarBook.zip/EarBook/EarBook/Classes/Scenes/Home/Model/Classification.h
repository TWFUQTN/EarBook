//
//  Classification.h
//  EarBook
//
//  Created by lanou3g on 16/6/28.
//  Copyright © 2016年 赵符壹. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Classification : NSObject

//name
@property (nonatomic, strong) NSString *name;

//pt
@property (nonatomic, strong) NSString *pt;

//url
@property (nonatomic, strong) NSString *url;

@end
