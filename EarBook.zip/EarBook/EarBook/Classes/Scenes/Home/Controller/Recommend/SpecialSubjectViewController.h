//
//  SpecialSubjectViewController.h
//  EarBook
//
//  Created by lanou3g on 16/6/28.
//  Copyright © 2016年 赵符壹. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SpecialSubjectViewController : UITableViewController

@property (nonatomic, strong) NSArray *bookArray;

@end
